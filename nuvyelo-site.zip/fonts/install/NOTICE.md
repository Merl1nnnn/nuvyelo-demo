# Installer fonts

The three installer fonts are renamed derivatives of Manrope, Caveat and Cormorant Garamond from the Google Fonts repository. Their isolated family names are Nuvyelo Sans, Nuvyelo Script and Nuvyelo Serif. This prevents replacement or shadowing of a user's pre-existing original font families. Outlines and layout tables are unchanged.

Each font is distributed under its accompanying SIL Open Font License 1.1. Original copyright notices remain in the font and license. These are separate from the web font packages used by the preview.

Rebuild: `scripts/build-install-fonts.py`, with fonttools 4.63.0. Source hashes are checked before parsing; resulting hashes are compiled into the Rust allowlist. Updates require an intentional allowlist change and review. No fonts or third-party code are downloaded by the installer.
