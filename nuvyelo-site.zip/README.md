# Nuvyelo — website test build

Ready-to-serve static frontend: editor, preview and installer export.
These features require no backend. Projects are saved in the browser.
The assets/fonts/wallpapers/installers directories are required by the site and export.
Installers are experimental; limitations are explained during export.
This repository contains the public build; the source project is stored separately.
